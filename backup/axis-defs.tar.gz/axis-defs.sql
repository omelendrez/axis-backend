-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: axis
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `certificate`
--

DROP TABLE IF EXISTS `certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificate` (
  `training` int NOT NULL,
  `number` int NOT NULL,
  PRIMARY KEY (`training`,`number`),
  CONSTRAINT `certificate_ibfk_1` FOREIGN KEY (`training`) REFERENCES `training` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `certificate_type`
--

DROP TABLE IF EXISTS `certificate_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificate_type` (
  `id` tinyint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `status` tinyint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3731 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_info`
--

DROP TABLE IF EXISTS `contact_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `learner` int NOT NULL,
  `type` tinyint NOT NULL,
  `value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contact_info_learner_idx` (`learner`),
  KEY `type` (`type`),
  CONSTRAINT `contact_info_ibfk_1` FOREIGN KEY (`learner`) REFERENCES `learner` (`id`),
  CONSTRAINT `contact_info_ibfk_2` FOREIGN KEY (`type`) REFERENCES `contact_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=446087 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_type`
--

DROP TABLE IF EXISTS `contact_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_type` (
  `id` tinyint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `front_id_text` varchar(100) DEFAULT NULL,
  `back_id_text` varchar(100) DEFAULT NULL,
  `id_card` tinyint DEFAULT NULL,
  `duration` tinyint DEFAULT NULL,
  `validity` tinyint DEFAULT NULL,
  `cert_type` tinyint DEFAULT NULL,
  `expiry_type` tinyint DEFAULT '1',
  `opito_reg_code` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cert_type` (`cert_type`),
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`cert_type`) REFERENCES `certificate_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=502 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `course_item`
--

DROP TABLE IF EXISTS `course_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_item` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `course_item_rel`
--

DROP TABLE IF EXISTS `course_item_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_item_rel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course` smallint DEFAULT NULL,
  `item` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course` (`course`),
  KEY `item` (`item`),
  CONSTRAINT `course_item_rel_ibfk_1` FOREIGN KEY (`course`) REFERENCES `course` (`id`),
  CONSTRAINT `course_item_rel_ibfk_2` FOREIGN KEY (`item`) REFERENCES `course_item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `course_module`
--

DROP TABLE IF EXISTS `course_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_module` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `course_module_rel`
--

DROP TABLE IF EXISTS `course_module_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_module_rel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course` smallint DEFAULT NULL,
  `module` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course` (`course`),
  KEY `module` (`module`),
  CONSTRAINT `course_module_rel_ibfk_1` FOREIGN KEY (`course`) REFERENCES `course` (`id`),
  CONSTRAINT `course_module_rel_ibfk_2` FOREIGN KEY (`module`) REFERENCES `course_module` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `course_summary`
--

DROP TABLE IF EXISTS `course_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_summary` (
  `course` smallint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `learner`
--

DROP TABLE IF EXISTS `learner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learner` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` char(3) DEFAULT NULL,
  `badge` varchar(100) NOT NULL,
  `title` tinyint DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `sex` char(1) NOT NULL,
  `state` smallint DEFAULT NULL,
  `nationality` smallint DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `company` smallint NOT NULL,
  `status` tinyint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `learner_badge_idx` (`badge`),
  KEY `title` (`title`),
  KEY `sex` (`sex`),
  KEY `state` (`state`),
  KEY `nationality` (`nationality`),
  KEY `company` (`company`),
  CONSTRAINT `learner_ibfk_1` FOREIGN KEY (`title`) REFERENCES `title` (`id`),
  CONSTRAINT `learner_ibfk_2` FOREIGN KEY (`sex`) REFERENCES `sex` (`id`),
  CONSTRAINT `learner_ibfk_3` FOREIGN KEY (`state`) REFERENCES `state` (`id`),
  CONSTRAINT `learner_ibfk_4` FOREIGN KEY (`nationality`) REFERENCES `nationality` (`id`),
  CONSTRAINT `learner_ibfk_5` FOREIGN KEY (`company`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=729715 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `learner_BEFORE_INSERT` BEFORE INSERT ON `learner` FOR EACH ROW BEGIN
	DECLARE last_badge VARCHAR(255) DEFAULT '';
    DECLARE new_badge INT DEFAULT 0;
    DECLARE prefix VARCHAR(2) DEFAULT '';

    IF NEW.type = 'TRN' THEN
		SET prefix = 'TR';
	END IF;

	SELECT
        REGEXP_REPLACE(MAX(badge), '[a-zA-Z]+', '')
    INTO
        last_badge
    FROM
        learner
    WHERE
        type=NEW.type;

    SET new_badge = CAST(last_badge AS UNSIGNED) + 1;

    SET NEW.badge = CONCAT(prefix, REGEXP_REPLACE(CAST(new_badge AS CHAR(10)),' ',''));
    SET NEW.last_name = UPPER(TRIM(NEW.last_name));
    SET NEW.first_name = UPPER(TRIM(NEW.first_name));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `learner_BEFORE_UPDATE` BEFORE UPDATE ON `learner` FOR EACH ROW BEGIN
    SET NEW.last_name = UPPER(TRIM(NEW.last_name));
    SET NEW.first_name = UPPER(TRIM(NEW.first_name));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `nationality`
--

DROP TABLE IF EXISTS `nationality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nationality` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `code` char(3) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `nationality` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nationality_code_idx` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=895 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sex`
--

DROP TABLE IF EXISTS `sex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sex` (
  `id` char(1) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `state` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status` (
  `id` tinyint NOT NULL AUTO_INCREMENT,
  `status` varchar(100) NOT NULL,
  `continue_flow` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `title`
--

DROP TABLE IF EXISTS `title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `title` (
  `id` tinyint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training`
--

DROP TABLE IF EXISTS `training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training` (
  `id` int NOT NULL AUTO_INCREMENT,
  `learner` int NOT NULL,
  `course` smallint NOT NULL,
  `start` date NOT NULL,
  `end` date DEFAULT NULL,
  `issued` date DEFAULT NULL,
  `prev_expiry` date DEFAULT NULL,
  `expiry` date DEFAULT NULL,
  `certificate` varchar(100) DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `opito_file` varchar(100) DEFAULT '',
  `opito_learner` varchar(100) DEFAULT '',
  `instructor` smallint DEFAULT NULL,
  `reject_reason` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `training_learner_idx` (`learner`),
  KEY `training_course_start_idx` (`course`,`start`),
  KEY `training_status_idx` (`status`),
  CONSTRAINT `training_ibfk_1` FOREIGN KEY (`learner`) REFERENCES `learner` (`id`),
  CONSTRAINT `training_ibfk_2` FOREIGN KEY (`course`) REFERENCES `course` (`id`),
  CONSTRAINT `training_ibfk_3` FOREIGN KEY (`status`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=286295 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `training_BEFORE_INSERT` BEFORE INSERT ON `training` FOR EACH ROW BEGIN
	DECLARE v_start DATE;
    DECLARE v_end DATE;
    DECLARE v_issued DATE;
    DECLARE v_prev_expiry DATE;
    DECLARE v_expiry DATE;
    DECLARE v_days SMALLINT;

    DECLARE v_duration TINYINT;
    DECLARE v_validity TINYINT;

    DECLARE v_expiry_type TINYINT;

    SET v_start = NEW.start;
    SET v_prev_expiry = NEW.prev_expiry;

    SELECT duration, validity, expiry_type
    INTO v_duration, v_validity, v_expiry_type
    FROM course
    WHERE id = NEW.course;

    SET v_end = DATE_ADD(v_start, INTERVAL v_duration-1 DAY);

    SET v_issued = v_end;

    IF v_expiry_type = 0 -- No expiration date
    THEN
        SET v_expiry = NULL;
    END IF;

    IF v_expiry_type = 1 -- Automatic
    THEN
        SET v_expiry = DATE_ADD(DATE_ADD(v_issued, INTERVAL v_validity YEAR), INTERVAL -1 DAY);
    END IF;

    IF v_expiry_type = 2 -- FOET
    THEN
        SET v_days = DATEDIFF(v_prev_expiry, v_issued);
        IF v_days BETWEEN 0 AND 60
        THEN
            SET v_expiry = DATE_ADD(DATE_ADD(v_prev_expiry, INTERVAL v_validity YEAR), INTERVAL -1 DAY);
        ELSE
            SET v_expiry = DATE_ADD(DATE_ADD(v_issued, INTERVAL v_validity YEAR), INTERVAL -1 DAY);
        END IF;
    END IF;

    SET NEW.end = v_end;
    SET NEW.issued = v_issued;
    SET NEW.expiry = v_expiry;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `training_instructor`
--

DROP TABLE IF EXISTS `training_instructor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_instructor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `training` int NOT NULL,
  `date` date NOT NULL,
  `module` smallint NOT NULL,
  `instructor` smallint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `instructor` (`instructor`),
  KEY `training_instructor_training_date_module_idx` (`training`,`date`,`module`,`instructor`),
  CONSTRAINT `training_instructor_ibfk_1` FOREIGN KEY (`training`) REFERENCES `training` (`id`),
  CONSTRAINT `training_instructor_ibfk_2` FOREIGN KEY (`module`) REFERENCES `course_module` (`id`),
  CONSTRAINT `training_instructor_ibfk_3` FOREIGN KEY (`instructor`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_medical`
--

DROP TABLE IF EXISTS `training_medical`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_medical` (
  `training` int NOT NULL,
  `date` date DEFAULT NULL,
  `systolic` smallint DEFAULT NULL,
  `diastolic` smallint DEFAULT NULL,
  KEY `training_medical_training_date_idx` (`training`,`date`),
  CONSTRAINT `training_medical_ibfk_1` FOREIGN KEY (`training`) REFERENCES `training` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `training_tracking`
--

DROP TABLE IF EXISTS `training_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_tracking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `training` int DEFAULT NULL,
  `status` tinyint NOT NULL,
  `user` smallint DEFAULT NULL,
  `updated` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `training_tracking_training_status_idx` (`training`,`status`),
  KEY `user` (`user`),
  KEY `status` (`status`),
  CONSTRAINT `training_tracking_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `training_tracking_ibfk_2` FOREIGN KEY (`status`) REFERENCES `status` (`id`),
  CONSTRAINT `training_tracking_ibfk_3` FOREIGN KEY (`training`) REFERENCES `training` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=663454 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `tracking_AFTER_INSERT` AFTER INSERT ON `training_tracking` FOR EACH ROW BEGIN

DECLARE v_training INT;
DECLARE v_year_start VARCHAR(2);
DECLARE v_year_born VARCHAR(2);
DECLARE v_number VARCHAR(12);

DECLARE v_cert_type TINYINT;

DECLARE v_certificate VARCHAR(100);

SET v_training = NEW.training;

SELECT DATE_FORMAT(t.start, '%y'), DATE_FORMAT(l.birth_date, '%y'), c.cert_type, t.certificate
INTO v_year_start, v_year_born, v_cert_type, v_certificate
FROM training t
INNER JOIN course c ON c.id = t.course
INNER JOIN learner l ON l.id = t.learner
WHERE t.id = v_training;

IF NEW.status = 7 -- QA_DONE
AND v_cert_type <> 4 -- OPITO
THEN

  SELECT MAX(number)+1
  INTO v_number
  FROM certificate;

  SELECT CONCAT('T', v_year_start, v_number, v_year_born)
  INTO v_certificate;

  UPDATE training
  SET certificate = v_certificate
  WHERE id = v_training;

  INSERT INTO certificate (training, number)
  VALUES (v_training, v_number);

END IF;

UPDATE
  training
SET
  status = NEW.status,
  certificate = v_certificate
WHERE
  id = NEW.training;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `tracking_BEFORE_DELETE` BEFORE DELETE ON `training_tracking` FOR EACH ROW BEGIN

	DECLARE v_training_id INT;
  DECLARE v_training_status TINYINT;
  DECLARE v_cert_type TINYINT;

  SELECT
    OLD.training, OLD.status
  INTO
    v_training_id, v_training_status;

  IF v_training_status = 4 THEN -- MEDIC_DONE
    DELETE FROM
      training_medical
    WHERE
      training = v_training_id;
  END IF;

  IF v_training_status = 7 THEN -- QA_DONE
    SELECT
      cert_type
    INTO
      v_cert_type
    FROM
      course
    WHERE
      id = (SELECT
              course
            FROM
              training
            WHERE
              id = v_training_id
            );

    IF v_cert_type <> 4 THEN -- OPITO
      DELETE FROM
        certificate
      WHERE
        training = v_training_id;

      UPDATE
        training
      SET
        certificate = ''
      WHERE
        id = v_training_id;

    END IF;

  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `tracking_AFTER_DELETE` AFTER DELETE ON `training_tracking` FOR EACH ROW BEGIN

  DECLARE v_new_status TINYINT;

  IF EXISTS (SELECT 1 FROM training_tracking WHERE training = OLD.training)
  THEN

    SELECT
      MAX(status)
    INTO
      v_new_status
    FROM
      training_tracking
    WHERE
      training = OLD.training;

    UPDATE
      training
    SET
      status = CASE WHEN v_new_status IS NULL THEN 0 ELSE v_new_status END
    WHERE
      id = OLD.training;

  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status` tinyint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1066 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` smallint NOT NULL,
  `role` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `role` (`role`),
  CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `user_role_ibfk_2` FOREIGN KEY (`role`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'axis'
--
/*!50003 DROP FUNCTION IF EXISTS `capitalize` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` FUNCTION `capitalize`(s VARCHAR(100)) RETURNS varchar(100) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
  RETURN CONCAT(UPPER(SUBSTRING(s,1,1)),LOWER(SUBSTRING(s,2)));
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-13 21:38:54
