LOCK TABLES contact_type WRITE;

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE contact_type;

UNLOCK TABLES;

LOCK TABLES contact_type WRITE;
SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO contact_type VALUES (2,'Personal Mobile'),(3,'Personal e-Mail'),(4,'Company Phone'),(5,'Company Mobile'),(6,'Company e-Mail'),(7,'Emergency Phone'),(8,'Emergency Mobile'),(9,'Extension');
SET FOREIGN_KEY_CHECKS = 1;

UNLOCK TABLES;

