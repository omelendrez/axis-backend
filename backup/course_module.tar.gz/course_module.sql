LOCK TABLES course_module WRITE;

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE course_module;

UNLOCK TABLES;

LOCK TABLES course_module WRITE;
SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO course_module VALUES (2,'Basic First Aid'),(3,'CA-EBS'),(4,'HUET & SAS'),(5,'Induction'),(6,'Swing Rope Transfer'),(7,'Elementary First Aid Regul. VI/I & Sect. A-VI/1-3'),(8,'Fire Prevention & Fire Fighting Regul. VI/I & Sect. A-VI/1-2'),(9,'Personal Safety & Social Responsibility Regul. VI/I & Sect. A-VI/1-4'),(10,'Personal Survival Techniques Regul. VI/1-1'),(11,'Proficiency in Security Awareness Regul. VI/I & Sect. A-VI/6-1'),(12,'Helicopter Landing Officer');
SET FOREIGN_KEY_CHECKS = 1;

UNLOCK TABLES;

