-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: axis
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nationality`
--

DROP TABLE IF EXISTS `nationality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nationality` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `code` char(3) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `nationality` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nationality_code_idx` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=895 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nationality`
--

LOCK TABLES `nationality` WRITE;
/*!40000 ALTER TABLE `nationality` DISABLE KEYS */;
INSERT INTO `nationality` VALUES (4,'AFG','Afghanistan','Afghan'),(8,'ALB','Albania','Albanian'),(10,'ATA','Antarctica','Antarctic'),(12,'DZA','Algeria','Algerian'),(16,'ASM','American Samoa','American Samoan'),(20,'AND','Andorra','Andorran'),(24,'AGO','Angola','Angolan'),(28,'ATG','Antigua and Barbuda','Antiguan or Barbudan'),(31,'AZE','Azerbaijan','Azerbaijani, Azeri'),(32,'ARG','Argentina','Argentine'),(36,'AUS','Australia','Australian'),(40,'AUT','Austria','Austrian'),(44,'BHS','Bahamas','Bahamian'),(48,'BHR','Bahrain','Bahraini'),(50,'BGD','Bangladesh','Bangladeshi'),(51,'ARM','Armenia','Armenian'),(52,'BRB','Barbados','Barbadian'),(56,'BEL','Belgium','Belgian'),(60,'BMU','Bermuda','Bermudian, Bermudan'),(64,'BTN','Bhutan','Bhutanese'),(68,'BOL','Bolivia (Plurinational State of)','Bolivian'),(70,'BIH','Bosnia and Herzegovina','Bosnian or Herzegovinian'),(72,'BWA','Botswana','Motswana, Botswanan'),(74,'BVT','Bouvet Island','Bouvet Island'),(76,'BRA','Brazil','Brazilian'),(84,'BLZ','Belize','Belizean'),(86,'IOT','British Indian Ocean Territory','BIOT'),(90,'SLB','Solomon Islands','Solomon Island'),(92,'VGB','Virgin Islands (British)','British Virgin Island'),(96,'BRN','Brunei Darussalam','Bruneian'),(100,'BGR','Bulgaria','Bulgarian'),(104,'MMR','Myanmar','Burmese'),(108,'BDI','Burundi','Burundian'),(112,'BLR','Belarus','Belarusian'),(116,'KHM','Cambodia','Cambodian'),(120,'CMR','Cameroon','Cameroonian'),(124,'CAN','Canada','Canadian'),(132,'CPV','Cabo Verde','Cabo Verdean'),(136,'CYM','Cayman Islands','Caymanian'),(140,'CAF','Central African Republic','Central African'),(144,'LKA','Sri Lanka','Sri Lankan'),(148,'TCD','Chad','Chadian'),(152,'CHL','Chile','Chilean'),(156,'CHN','China','Chinese'),(158,'TWN','Taiwan, Province of China','Chinese, Taiwanese'),(162,'CXR','Christmas Island','Christmas Island'),(166,'CCK','Cocos (Keeling) Islands','Cocos Island'),(170,'COL','Colombia','Colombian'),(174,'COM','Comoros','Comoran, Comorian'),(175,'MYT','Mayotte','Mahoran'),(178,'COG','Congo (Republic of the)','Congolese'),(180,'COD','Congo (Democratic Republic of the)','Congolese'),(184,'COK','Cook Islands','Cook Island'),(188,'CRI','Costa Rica','Costa Rican'),(191,'HRV','Croatia','Croatian'),(192,'CUB','Cuba','Cuban'),(196,'CYP','Cyprus','Cypriot'),(203,'CZE','Czech Republic','Czech'),(204,'BEN','Benin','Beninese, Beninois'),(208,'DNK','Denmark','Danish'),(212,'DMA','Dominica','Dominican'),(214,'DOM','Dominican Republic','Dominican'),(218,'ECU','Ecuador','Ecuadorian'),(222,'SLV','El Salvador','Salvadoran'),(226,'GNQ','Equatorial Guinea','Equatorial Guinean, Equatoguinean'),(231,'ETH','Ethiopia','Ethiopian'),(232,'ERI','Eritrea','Eritrean'),(233,'EST','Estonia','Estonian'),(234,'FRO','Faroe Islands','Faroese'),(238,'FLK','Falkland Islands (Malvinas)','Falkland Island'),(239,'SGS','South Georgia and the South Sandwich Islands','South Georgia or South Sandwich Islands'),(242,'FJI','Fiji','Fijian'),(246,'FIN','Finland','Finnish'),(248,'ALA','Åland Islands','Åland Island'),(250,'FRA','France','French'),(254,'GUF','French Guiana','French Guianese'),(258,'PYF','French Polynesia','French Polynesian'),(260,'ATF','French Southern Territories','French Southern Territories'),(262,'DJI','Djibouti','Djiboutian'),(266,'GAB','Gabon','Gabonese'),(268,'GEO','Georgia','Georgian'),(270,'GMB','Gambia','Gambian'),(275,'PSE','Palestine, State of','Palestinian'),(276,'DEU','Germany','German'),(288,'GHA','Ghana','Ghanaian'),(292,'GIB','Gibraltar','Gibraltar'),(296,'KIR','Kiribati','I-Kiribati'),(300,'GRC','Greece','Greek, Hellenic'),(304,'GRL','Greenland','Greenlandic'),(308,'GRD','Grenada','Grenadian'),(312,'GLP','Guadeloupe','Guadeloupe'),(316,'GUM','Guam','Guamanian, Guambat'),(320,'GTM','Guatemala','Guatemalan'),(324,'GIN','Guinea','Guinean'),(328,'GUY','Guyana','Guyanese'),(332,'HTI','Haiti','Haitian'),(334,'HMD','Heard Island and McDonald Islands','Heard Island or McDonald Islands'),(336,'VAT','Vatican City State','Vatican'),(340,'HND','Honduras','Honduran'),(344,'HKG','Hong Kong','Hong Kong, Hong Kongese'),(348,'HUN','Hungary','Hungarian, Magyar'),(352,'ISL','Iceland','Icelandic'),(356,'IND','India','Indian'),(360,'IDN','Indonesia','Indonesian'),(364,'IRN','Iran','Iranian, Persian'),(368,'IRQ','Iraq','Iraqi'),(372,'IRL','Ireland','Irish'),(376,'ISR','Israel','Israeli'),(380,'ITA','Italy','Italian'),(384,'CIV','Côte d\'Ivoire','Ivorian'),(388,'JAM','Jamaica','Jamaican'),(392,'JPN','Japan','Japanese'),(398,'KAZ','Kazakhstan','Kazakhstani, Kazakh'),(400,'JOR','Jordan','Jordanian'),(404,'KEN','Kenya','Kenyan'),(408,'PRK','Korea (Democratic People\'s Republic of)','North Korean'),(410,'KOR','Korea (Republic of)','South Korean'),(414,'KWT','Kuwait','Kuwaiti'),(417,'KGZ','Kyrgyzstan','Kyrgyzstani, Kyrgyz, Kirgiz, Kirghiz'),(418,'LAO','Lao People\'s Democratic Republic','Lao, Laotian'),(422,'LBN','Lebanon','Lebanese'),(426,'LSO','Lesotho','Basotho'),(428,'LVA','Latvia','Latvian'),(430,'LBR','Liberia','Liberian'),(434,'LBY','Libya','Libyan'),(438,'LIE','Liechtenstein','Liechtenstein'),(440,'LTU','Lithuania','Lithuanian'),(442,'LUX','Luxembourg','Luxembourg, Luxembourgish'),(446,'MAC','Macao','Macanese, Chinese'),(450,'MDG','Madagascar','Malagasy'),(454,'MWI','Malawi','Malawian'),(458,'MYS','Malaysia','Malaysian'),(462,'MDV','Maldives','Maldivian'),(466,'MLI','Mali','Malian, Malinese'),(470,'MLT','Malta','Maltese'),(474,'MTQ','Martinique','Martiniquais, Martinican'),(478,'MRT','Mauritania','Mauritanian'),(480,'MUS','Mauritius','Mauritian'),(484,'MEX','Mexico','Mexican'),(492,'MCO','Monaco','Monégasque, Monacan'),(496,'MNG','Mongolia','Mongolian'),(498,'MDA','Moldova (Republic of)','Moldovan'),(499,'MNE','Montenegro','Montenegrin'),(500,'MSR','Montserrat','Montserratian'),(504,'MAR','Morocco','Moroccan'),(508,'MOZ','Mozambique','Mozambican'),(512,'OMN','Oman','Omani'),(516,'NAM','Namibia','Namibian'),(520,'NRU','Nauru','Nauruan'),(524,'NPL','Nepal','Nepali, Nepalese'),(528,'NLD','Netherlands','Dutch, Netherlandic'),(531,'CUW','Curaçao','Curaçaoan'),(533,'ABW','Aruba','Aruban'),(534,'SXM','Sint Maarten (Dutch part)','Sint Maarten'),(535,'BES','Bonaire, Sint Eustatius and Saba','Bonaire'),(540,'NCL','New Caledonia','New Caledonian'),(548,'VUT','Vanuatu','Ni-Vanuatu, Vanuatuan'),(554,'NZL','New Zealand','New Zealand, NZ'),(558,'NIC','Nicaragua','Nicaraguan'),(562,'NER','Niger','Nigerien'),(566,'NGA','Nigeria','Nigerian'),(570,'NIU','Niue','Niuean'),(574,'NFK','Norfolk Island','Norfolk Island'),(578,'NOR','Norway','Norwegian'),(580,'MNP','Northern Mariana Islands','Northern Marianan'),(581,'UMI','United States Minor Outlying Islands','American'),(583,'FSM','Micronesia (Federated States of)','Micronesian'),(584,'MHL','Marshall Islands','Marshallese'),(585,'PLW','Palau','Palauan'),(586,'PAK','Pakistan','Pakistani'),(591,'PAN','Panama','Panamanian'),(598,'PNG','Papua New Guinea','Papua New Guinean, Papuan'),(600,'PRY','Paraguay','Paraguayan'),(604,'PER','Peru','Peruvian'),(608,'PHL','Philippines','Philippine, Filipino'),(612,'PCN','Pitcairn','Pitcairn Island'),(616,'POL','Poland','Polish'),(620,'PRT','Portugal','Portuguese'),(624,'GNB','Guinea-Bissau','Bissau-Guinean'),(626,'TLS','Timor-Leste','Timorese'),(630,'PRI','Puerto Rico','Puerto Rican'),(634,'QAT','Qatar','Qatari'),(638,'REU','Réunion','Réunionese, Réunionnais'),(642,'ROU','Romania','Romanian'),(643,'RUS','Russian Federation','Russian'),(646,'RWA','Rwanda','Rwandan'),(652,'BLM','Saint Barthélemy','Barthélemois'),(654,'SHN','Saint Helena, Ascension and Tristan da Cunha','Saint Helenian'),(659,'KNA','Saint Kitts and Nevis','Kittitian or Nevisian'),(660,'AIA','Anguilla','Anguillan'),(662,'LCA','Saint Lucia','Saint Lucian'),(663,'MAF','Saint Martin (French part)','Saint-Martinoise'),(666,'SPM','Saint Pierre and Miquelon','Saint-Pierrais or Miquelonnais'),(670,'VCT','Saint Vincent and the Grenadines','Saint Vincentian, Vincentian'),(674,'SMR','San Marino','Sammarinese'),(678,'STP','Sao Tome and Principe','São Toméan'),(682,'SAU','Saudi Arabia','Saudi, Saudi Arabian'),(686,'SEN','Senegal','Senegalese'),(688,'SRB','Serbia','Serbian'),(690,'SYC','Seychelles','Seychellois'),(694,'SLE','Sierra Leone','Sierra Leonean'),(702,'SGP','Singapore','Singaporean'),(703,'SVK','Slovakia','Slovak'),(704,'VNM','Vietnam','Vietnamese'),(705,'SVN','Slovenia','Slovenian, Slovene'),(706,'SOM','Somalia','Somali, Somalian'),(710,'ZAF','South Africa','South African'),(716,'ZWE','Zimbabwe','Zimbabwean'),(724,'ESP','Spain','Spanish'),(728,'SSD','South Sudan','South Sudanese'),(729,'SDN','Sudan','Sudanese'),(732,'ESH','Western Sahara','Sahrawi, Sahrawian, Sahraouian'),(740,'SUR','Suriname','Surinamese'),(744,'SJM','Svalbard and Jan Mayen','Svalbard'),(748,'SWZ','Swaziland','Swazi'),(752,'SWE','Sweden','Swedish'),(756,'CHE','Switzerland','Swiss'),(760,'SYR','Syrian Arab Republic','Syrian'),(762,'TJK','Tajikistan','Tajikistani'),(764,'THA','Thailand','Thai'),(768,'TGO','Togo','Togolese'),(772,'TKL','Tokelau','Tokelauan'),(776,'TON','Tonga','Tongan'),(780,'TTO','Trinidad and Tobago','Trinidadian or Tobagonian'),(784,'ARE','United Arab Emirates','Emirati, Emirian, Emiri'),(788,'TUN','Tunisia','Tunisian'),(792,'TUR','Turkey','Turkish'),(795,'TKM','Turkmenistan','Turkmen'),(796,'TCA','Turks and Caicos Islands','Turks and Caicos Island'),(798,'TUV','Tuvalu','Tuvaluan'),(800,'UGA','Uganda','Ugandan'),(804,'UKR','Ukraine','Ukrainian'),(807,'MKD','Macedonia (the former Yugoslav Republic of)','Macedonian'),(818,'EGY','Egypt','Egyptian'),(826,'GBR','United Kingdom of Great Britain and Northern Ireland','British, UK'),(831,'GGY','Guernsey','Channel Island'),(832,'JEY','Jersey','Channel Island'),(833,'IMN','Isle of Man','Manx'),(834,'TZA','Tanzania, United Republic of','Tanzanian'),(840,'USA','United States of America','American'),(850,'VIR','Virgin Islands (U.S.)','U.S. Virgin Island'),(854,'BFA','Burkina Faso','Burkinabé'),(858,'URY','Uruguay','Uruguayan'),(860,'UZB','Uzbekistan','Uzbekistani, Uzbek'),(862,'VEN','Venezuela (Bolivarian Republic of)','Venezuelan'),(876,'WLF','Wallis and Futuna','Wallis and Futuna, Wallisian or Futunan'),(882,'WSM','Samoa','Samoan'),(887,'YEM','Yemen','Yemeni'),(894,'ZMB','Zambia','Zambian');
/*!40000 ALTER TABLE `nationality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'axis'
--
/*!50003 DROP FUNCTION IF EXISTS `capitalize` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `capitalize`(s VARCHAR(100)) RETURNS varchar(100) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
  RETURN CONCAT(UPPER(SUBSTRING(s,1,1)),LOWER(SUBSTRING(s,2)));
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-14 18:56:01
