LOCK TABLES role WRITE;

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE role;

UNLOCK TABLES;

LOCK TABLES role WRITE;
SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO role VALUES (2,'Admin'),(3,'Front desk'),(4,'Medic'),(5,'Training Coordinator'),(6,'Accounts'),(7,'QA/QC'),(8,'MD'),(9,'Printer'),(10,'Instructor');
SET FOREIGN_KEY_CHECKS = 1;

UNLOCK TABLES;

