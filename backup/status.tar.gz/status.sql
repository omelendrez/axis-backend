LOCK TABLES status WRITE;

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE status;

UNLOCK TABLES;

LOCK TABLES status WRITE;
SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO status VALUES (2,'Admin done',1),(3,'Front desk done',1),(4,'Medic done',1),(5,'Training Coordinator done',1),(6,'Accounts done',1),(7,'QA/QC done',1),(8,'MD done',1),(9,'Certificate done',1),(10,'ID Card done',1),(11,'Completed',0),(12,'Cancelled',0),(13,'Rejected',1);
SET FOREIGN_KEY_CHECKS = 1;

UNLOCK TABLES;

