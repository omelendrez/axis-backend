-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: 192.168.0.214    Database: axis
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course_item`
--

DROP TABLE IF EXISTS `course_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_item` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_item`
--

LOCK TABLES `course_item` WRITE;
/*!40000 ALTER TABLE `course_item` DISABLE KEYS */;
INSERT INTO `course_item` VALUES (1,'* Helicopter Underwater Escape Technique (HUET)'),(2,'* Survival At Sea (SAS)'),(3,'* Basic Fire Fighting (BFF)'),(4,'* Basic First Aid & CPR'),(5,'* Advanced First Aid (AED)'),(7,'* Advanced Fire Fighting (AFF)'),(8,'* Breathing Aparatus (BA)'),(9,'* Helideck Fire Fighting (HFF)'),(10,'* Helicopter Landing Officer (HLO)'),(11,'* Helideck Assistant (HDA)'),(15,'* Personal Survival Swimming (PSS)'),(18,'* Swing Rope Transfer (SRT)'),(21,'* Confined Space Entry (CSE)'),(22,'* Methanol Awareness (MA)'),(23,'STCW 95 Regulation VI/2, Para. 1 and STCW Code Section A-VI/2-1'),(24,'Personal Survival Techniques            Regul. VI/I & Sect. A-VI/I - 1'),(25,'Fire Prevention & Fire Fighting         Regul. VI/I & Sect. A-VI/1 - 2'),(26,'Elementary First Aid                    Regul. VI/I & Sect. A-VI/1 - 3'),(27,'Personal Safety & Social Responsibility Regul. VI/I & Sect. A-VI/I - 4'),(28,'* Basic Fire Fighting & Self Rescue'),(29,'* Basic First Aid (BFA)'),(32,'* Wet Dinghy Drill (WDD)'),(37,'Pedestal Crane Operation'),(38,'* Fire Extinguisher Drill (FED)'),(40,'Proficiency in Survival Craft and Rescue Boat Other Than Fast Rescue Boat'),(41,'Air Crew Ditching (ACD)'),(42,'*Tropical Helicopter Underwater Escape Technique (THUET)'),(43,'* Offshore Emergency Response Team Member (OERTM)'),(44,'* Offshore Emergency Response Team Leader (OERTL)'),(45,'* Helicopter Landing Assistant (HLA)'),(47,'* Fire Team Member'),(48,'* Fire Team Member (Refresher)'),(49,'* Helideck Emergency Response Team Leader'),(50,'* Helideck Emergency Response Team Member'),(52,'With Emergency Breathing System (EBS)'),(55,'OPITO APPROVED COURSE - CODE: 5501'),(56,'Tropical Basic Offshore Safety Induction Emergency Training'),(57,'OPITO APPROVED COURSE - CODE: 5195'),(58,'OPITO APPROVED COURSE - CODE: 5614'),(60,'Tropical Further Offshore Emergency Training'),(61,'Basic Offshore Safety Induction Emergency Training (BOSIET)'),(62,'Further Offshore Emergency Training (FOET)'),(63,'Helicopter Underwater Escape Training (HUET)'),(64,'OPITO APPROVED COURSE - CODE: 5700'),(65,'OPITO APPROVED COURSE - CODE: 5858'),(66,'OPITO APPROVED COURSE - CODE: 5095'),(67,'Proficiency in Security Awareness       Regul. VI/I & Sect. A-VI/6 - 1'),(68,'* Short Term Air Supply System (HEEDS 3)'),(71,'With Compressed Air Emergency Breathing System (CA-EBS)'),(72,'(CA-EBS) Initial Deployment Training'),(73,'OPITO APPROVED COURSE - CODE: 5902'),(74,'OPITO APPROVED COURSE - CODE: 5750'),(75,'OPITO APPROVED COURSE - CODE: 5295'),(76,'OPITO APPROVED COURSE - CODE: 5850'),(78,'* Helideck Team Member'),(79,'* Automated External Defibrillator (AED)'),(80,'* Incipient Fire Fighting'),(81,'* Fork Lift Training'),(82,'Offshore Crane Operator'),(83,'Fire Fighting and Fire Prevention Training'),(84,'Banksman and Slinging Training'),(85,'* Transportation of Dangerous Goods By Air & Sea'),(86,'DIGITAL DELIVERY'),(87,'OPITO APPROVED COURSE - CODE: 5507'),(88,'OPITO APPROVED COURSE - CODE: 5703'),(89,'OPITO APPROVED COURSE - CODE: 5752'),(90,'(T-BOSIET)'),(91,'Compressed Air Emergency Breathing System (CA-EBS)'),(92,'* Fire Team Leader'),(93,'* Advanced Breathing Apparatus'),(94,'* Transportation of Dangerous Goods By Air'),(95,'* Transportation of Dangerous Goods By Sea'),(96,'* Scaffolding Training'),(97,'* Radio Communication'),(98,'* Spill Response Training'),(99,'* Fire Warden Training'),(100,'* Dangerous Goods Awareness Training'),(101,'* Helicopter Landing Officer Refresher Training'),(102,'T-HUET'),(103,'* Hydrogen II Sulphide'),(104,'Rigging & Slinging'),(105,'* Helicopter Fire Fighting'),(106,'Helideck Operations Initial Training (HOIT)'),(107,'OPITO APPROVED COURSE - CODE: 7040'),(108,'* Advanced Process and Materials Safety'),(109,'In'),(110,'Offshore Operations'),(111,'* First Aider Training'),(112,'* Medical First Aid Training'),(113,'* Major Emergency Management Initial Response (MEMIR)'),(114,'* Emergency Response Train the Trainer');
/*!40000 ALTER TABLE `course_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-19  8:15:52
