-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: 192.168.0.214    Database: axis
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status` tinyint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1067 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Axis','Axis Automatic','','',0),(95,'omar','Omar Melendrez','$2b$10$hAfvDf6gZEZrCObVHeYafe2bSQKhKHFP5yMJ7Xp1bNxlZSArIaXt6','omar.melendrez@gmail.com',1),(1023,'ndubuisi','Ndubuisi Nwabueze','$2b$10$FJf5H4l7oO0nil1SRlKbEOUcx.iFnBMAelg1UrS1CcRb8gx/g6yuK','ndubuisi@tolmann.com',1),(1024,'Roseline','Roseline Azubuike','$2b$10$OBEqgJiQPVlD5JNHp2hfQeUfKuw.CXHsuR9jqO9VGs34GkqO995lW','medic@tolmann.com',1),(1028,'Amarachi','Amarachi Amarachi','$2b$10$28d/yFYdHrQRIpluLy.0SeBosKZfupY1TM/BDr70c35HWzEtfnx8S','trainingintra@tolmann.com',1),(1030,'mercy','Mercy David','$2b$10$cC1jeATDsikYe5u3wS3jbOU2PUs.fQmt/IWvGMX3BhixuxZU2bPgG','mercy@tolmann.com',1),(1033,'Samuel','Ijeh Samuel','$2b$10$2ZqtK51h6.tze/YQNB46NOg03Vl/BW539Z6npZxwDWPFEfub5v.EO','samuel@tolmann.com',1),(1034,'Helen','Helen Helen','$2b$10$7BJQZXFPBXufvla17TBRXeWmO9QK484rTEwwuYuCebYJEWp49hm7m','billing@tolmann.com',1),(1036,'Isioma','Nwabueze Isioma','$2b$10$lSUbnAtL7FHnE27cUz5DyurNcpijr9cdChmVetJdOEjFp1wHVkec2','operations@tolmann.com',1),(1040,'Christiana','Christiana Nelson Ukaegbu','$2b$10$ytAGitwGXG5eHXjbl/WrZuwc4QOmRcwlVTVYHN3Dd5Ug8Sy63V.5K','medic@tolmann.com',1),(1048,'Benjamin','Benjamin Nnabo','$2b$10$gs66KGpts9/s9/fkRZlopO0Xhbz9firAEQlL.r6zcXjS69AXqkHzO','solutions@tolmann.com',1),(1056,'Blessing','Blessing Ogbuefi','$2b$10$vwz0aE/NKh2sBtT4hA/Z4OFKkfLw14mvqV06D1aku1p3Y8nCLes02','hr@tolmann.com',1),(1057,'Charles','Charles Azubuike','$2b$10$/fCSnoGAPoHw9RZy6ukujOiC.RuSYMFDkSfKn6NzQk7kSnO4WEnEC','operations@tolmann.com',1),(1058,'Song','Songofaa Briggs','$2b$10$85zMZ9Ao1PMHTF6VU9tUi.Rpsi.ZB0b0rvYx.MYNpUS9ec8EFi4DW','operations@tolmann.com',1),(1059,'West','West Owunari','$2b$10$bsmFE/HfohEcZaLpHoO5Kun02ecpDLNCWDI1FiNHwxRDKEAbiH8Qq','operations@tolmann.com',1),(1060,'Abigail','Abigail Abanum','$2b$10$RA905C.3IqCyymO8HmYxBOq95xiaATgxxgjrS.UaLkToCYT4pXhyS','trainingintra@tolmann.com',1),(1061,'Dorathy','Dorathy Okonkwo','$2b$10$qmCj/oJayRhJw9KExfdVaeKw.BgRATj1IDZwfQLGQnKsFvXyKnjc.','admin@tolmann.com',1),(1062,'MD','Emmanuel Onyekwena','$2b$10$oFh0e6qDCdCKrq56kKNNBOmsRiZYw.SwEdZX9GjOQ9FH3ICClJ1Vi','tolmann@tolmann.com',1),(1063,'Nnenna','Perpetual Nnenna Okoh','$2b$10$SJOAYrEuxCdymi9IJySITuifBxUHR/MpXb4fUQFjVjQY6oUhcAs0.','cs@tolmann.com',1),(1064,'Sandra','Sandra Iwunze','$2b$10$Ypndf3OKkfqKLaW7zWoFF.FdJmyOU9oAst.EZCQK1Tl068L.q1gmu','trainingintra@tolmann.com',1),(1065,'Ndidi','Ndidi Nzekwe','$2b$10$LLPKnQ4cEFP5LjRxlxRh6OZs3JufzbLbB/sG8LgnirCLsB9NBbJOa','finance2@tolmann.com',1),(1066,'Anita','Anita Raji','$2b$10$Qrer/R5qfu7zw4QgoY539.CapR7lly3dbAsEmOFtmNbo7gc00Ri4W','admin@tolmann.com',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-19  8:15:47
